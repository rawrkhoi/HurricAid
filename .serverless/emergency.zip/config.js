const keys = {
  ipapi: 'd2667cce8c17afd99dddc4588ca1e2a3',
  googleMaps: 'AIzaSyCJxy0YJDTlt5QJFZxNDakpjobG3luLy1I',
  predictHQ: 'EkWx2q2QUXK2xK6gtOyZzBlMCr6yWK',
  awsAccessKey: 'AKIAII4AQLA2D3KBAFGQ',
  awsSecretKey: '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',
  saveuserAccessKey: 'AKIAI2NHIEIYGS5DTYEA',
  saveuserSecretKey: 'ZyI4akxvRurXTDxo/LW6hUvFa4/QoAl6ow4HXdBj',
}
const config = {
  accountSid: 'ACadaafe6d1b07ff4e8a4bd6eb95f435b6', // Your Account SID from www.twilio.com/console
  authToken: '6eadca162dbdb2ef891ca200b6ff2a17',   // Your Auth Token from www.twilio.com/console
  assistant: 'UA4ae49c7575e49809a54316a545cb5ea0',
};
module.exports = {
  config,
  keys
}

